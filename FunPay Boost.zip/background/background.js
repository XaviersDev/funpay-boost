const BUMP_ALARM_NAME = 'funpayBoostAutoBump';

// УЛУЧШЕННАЯ ФУНКЦИЯ: Получение данных авторизации с несколькими попытками
async function getAuthDetails() {
    // 1. Получаем golden_key cookie - это основа
    const goldenKeyCookie = await chrome.cookies.get({ url: 'https://funpay.com', name: 'golden_key' });
    if (!goldenKeyCookie || !goldenKeyCookie.value) {
        throw new Error('Не удалось найти cookie "golden_key". Вы вошли в свой аккаунт FunPay?');
    }
    const golden_key = goldenKeyCookie.value;

    // 2. Пытаемся получить appData от любой активной вкладки
    const tabs = await chrome.tabs.query({ url: "https://funpay.com/*" });
    if (tabs.length > 0) {
        for (const tab of tabs) {
            // Пропускаем "спящие" вкладки
            if (tab.discarded) continue;
            try {
                const response = await chrome.tabs.sendMessage(tab.id, { action: "getAppData" });
                if (response && response.success) {
                    const appData = JSON.parse(response.data);
                    const userId = appData.userId;
                    const csrfToken = appData['csrf-token'];
                    if (userId && csrfToken) {
                        console.log("[FunPay Boost] Данные авторизации получены от активной вкладки.");
                        return { cookies: `golden_key=${golden_key}`, userId, csrfToken };
                    }
                }
            } catch (e) {
                console.warn(`[FunPay Boost] Не удалось связаться с вкладкой ${tab.id}. Пробую следующую.`);
            }
        }
    }

    // 3. ЗАПАСНОЙ ВАРИАНТ: Если ни одна вкладка не ответила, делаем прямой запрос
    console.log("[FunPay Boost] Ни одна вкладка не ответила, делаю прямой запрос к FunPay...");
    try {
        const response = await fetch("https://funpay.com/", {
            headers: { "cookie": `golden_key=${golden_key}` }
        });
        if (!response.ok) throw new Error(`Статус ответа сервера: ${response.status}`);
        
        const text = await response.text();
        const appDataMatch = text.match(/<body[^>]*data-app-data="([^"]+)"/);
        
        if (appDataMatch && appDataMatch[1]) {
            const appDataString = appDataMatch[1].replace(/&quot;/g, '"');
            const appData = JSON.parse(appDataString);
            const userId = appData.userId;
            const csrfToken = appData['csrf-token'];
            
            if (userId && csrfToken) {
                console.log("[FunPay Boost] Данные авторизации успешно получены через прямой запрос.");
                return { cookies: `golden_key=${golden_key}`, userId, csrfToken };
            }
        }
        throw new Error("Не удалось найти data-app-data в HTML страницы.");
    } catch (e) {
        console.error("[FunPay Boost] Прямой запрос для получения данных тоже провалился.", e.message);
        throw new Error("Не удалось получить данные для авторизации. Попробуйте перезагрузить страницу FunPay.");
    }
}


// Надежная функция поднятия категории, которая обрабатывает модальные окна
async function raiseCategory(categoryData, auth) {
    const { cookies, csrfToken } = auth;
    const { gameId, nodeId, categoryName } = categoryData;
    
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie': cookies,
        'X-Requested-With': 'XMLHttpRequest',
        'X-Csrf-Token': csrfToken
    };
    
    const initialData = new URLSearchParams({ game_id: gameId, node_id: nodeId });
    let response = await fetch('https://funpay.com/lots/raise', { method: 'POST', headers, body: initialData.toString() });
    let responseText = await response.text();

    try {
        const jsonResponse = JSON.parse(responseText);
        if (jsonResponse.modal) {
            const checkboxRegex = /<input[^>]*value="(\d+)"/g;
            const nodeIds = Array.from(jsonResponse.modal.matchAll(checkboxRegex), match => match[1]);

            if (nodeIds.length > 0) {
                const multiRaiseData = new URLSearchParams({ game_id: gameId, node_id: nodeId });
                nodeIds.forEach(id => multiRaiseData.append('node_ids[]', id));
                
                response = await fetch('https://funpay.com/lots/raise', { method: 'POST', headers, body: multiRaiseData.toString() });
                responseText = await response.text();
            } else {
                 return { success: false, error: `Не найдены подкатегории в модальном окне для "${categoryName}".` };
            }
        }
    } catch (e) { /* Не JSON */ }
    
    if (responseText.includes('подняты') || responseText.includes('raised')) {
        return { success: true };
    } else {
        let errorMsg = "Неизвестная ошибка";
        try {
            const errJson = JSON.parse(responseText);
            errorMsg = errJson.msg || JSON.stringify(errJson);
        } catch(e) {
            errorMsg = responseText.replace(/<[^>]*>/g, '').trim();
        }
        return { success: false, error: errorMsg };
    }
}


// Главный цикл поднятия лотов
async function runBumpCycle() {
    console.log(`[FunPay Boost] ${new Date().toLocaleTimeString()}: Запуск цикла поднятия...`);
    
    try {
        const auth = await getAuthDetails();
        const userUrl = `https://funpay.com/users/${auth.userId}/`;
        const userPageResponse = await fetch(userUrl, { headers: { 'Cookie': auth.cookies } });
        const userPageHtml = await userPageResponse.text();

        const categoryLinkRegex = /<a[^>]+href="([^"]+)"[^>]*class="[^"]*btn-plus[^"]*"/g;
        const categoryUrls = Array.from(userPageHtml.matchAll(categoryLinkRegex), match => match[1])
                                  .map(path => new URL(path, 'https://funpay.com/').href);

        if (categoryUrls.length === 0) {
            const message = "Не найдено лотов для поднятия (нет кнопок '+' на странице профиля).";
            console.log(`[FunPay Boost] ${message}`);
            return { success: true, message: message };
        }

        let successCount = 0;
        for (const categoryUrl of categoryUrls) {
            const categoryPageResponse = await fetch(categoryUrl, { headers: { 'Cookie': auth.cookies } });
            
            const categoryPageHtml = await categoryPageResponse.text();
            const categoryNameMatch = categoryPageHtml.match(/<h1 class="page-header">\s*<span class="inside">([\s\S]*?)<\/span>/);
            const categoryName = categoryNameMatch ? categoryNameMatch[1].trim() : categoryUrl;
            
            if (!categoryPageResponse.ok) {
                console.error(`[FunPay Boost] Не удалось поднять "${categoryName}". Ошибка загрузки страницы ${categoryPageResponse.status}.`);
                continue;
            }
            
            const raiseButtonRegex = /<button[^>]+class="[^"]*js-lot-raise[^"]*"[^>]*data-game="(\d+)"[^>]*data-node="([^"]+)"/;
            const raiseButtonMatch = categoryPageHtml.match(raiseButtonRegex);

            if (raiseButtonMatch) {
                const categoryData = { 
                    gameId: raiseButtonMatch[1], 
                    nodeId: raiseButtonMatch[2],
                    categoryName: categoryName
                };
                console.log(`[FunPay Boost] Поднимаю: ${categoryName}`);
                const result = await raiseCategory(categoryData, auth);
                if (result.success) {
                    successCount++;
                    console.log(`[FunPay Boost] Успешно поднято: ${categoryName}`);
                } else {
                    console.error(`[FunPay Boost] Не удалось поднять "${categoryName}": ${result.error}`);
                }
            } else {
                console.log(`[FunPay Boost] В категории "${categoryName}" лоты уже подняты или нет кнопки.`);
            }
            await new Promise(resolve => setTimeout(resolve, 3000));
        }
        
        const message = `Поднято ${successCount} из ${categoryUrls.length} категорий.`;
        console.log(`[FunPay Boost] ${message}`);
        return { success: true, message };

    } catch (error) {
        console.error(`[FunPay Boost] Критическая ошибка в цикле: ${error.message}`);
        return { success: false, error: error.message };
    }
}


// Управление будильником
async function startAutoBump(cooldownMinutes) {
    await chrome.alarms.create(BUMP_ALARM_NAME, { 
        delayInMinutes: 1, 
        periodInMinutes: parseInt(cooldownMinutes, 10) 
    });
    console.log(`[FunPay Boost] Автоподнятие запущено. Первый запуск через 1 минуту, далее каждые ${cooldownMinutes} мин.`);
}

async function stopAutoBump() {
    await chrome.alarms.clear(BUMP_ALARM_NAME);
    console.log("[FunPay Boost] Автоподнятие остановлено.");
}

// Слушатель будильника
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === BUMP_ALARM_NAME) {
        await runBumpCycle();
    }
});

// Слушатель сообщений от popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'startAutoBump') {
        startAutoBump(request.cooldown).then(() => sendResponse({ success: true }));
        return true;
    }
    if (request.action === 'stopAutoBump') {
        stopAutoBump().then(() => sendResponse({ success: true }));
        return true;
    }
    if (request.action === 'manualBump') {
        runBumpCycle().then(sendResponse);
        return true;
    }
    return false;
});

// Событие при установке
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        chrome.tabs.create({ url: chrome.runtime.getURL('install/install.html') });
        chrome.storage.local.set({
            autoBumpEnabled: false,
            autoBumpCooldown: 245
        });
    }
});

// Перезапуск будильника при запуске браузера
chrome.runtime.onStartup.addListener(async () => {
    const { autoBumpEnabled, autoBumpCooldown } = await chrome.storage.local.get(['autoBumpEnabled', 'autoBumpCooldown']);
    if (autoBumpEnabled) {
        const alarm = await chrome.alarms.get(BUMP_ALARM_NAME);
        if (!alarm) {
            startAutoBump(autoBumpCooldown || 245);
        }
    }
});