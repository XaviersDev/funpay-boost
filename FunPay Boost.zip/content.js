chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getAppData") {
        try {
            const appDataString = document.body.dataset.appData;
            if (!appDataString) {
                sendResponse({ success: false, error: "data-app-data не найдено на странице" });
            } else {
                // Отправляем как строку, парсинг будет в background
                sendResponse({ success: true, data: appDataString });
            }
        } catch (e) {
            sendResponse({ success: false, error: e.message });
        }
        return true; 
    }
});