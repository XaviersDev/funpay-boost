document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.getElementById('autoBumpToggle');
    const toggleLabel = document.getElementById('toggleLabel');
    const cooldownInput = document.getElementById('cooldownInput');
    const statusText = document.getElementById('statusText');
    const statusIndicator = document.getElementById('statusIndicator');
    const manualBumpBtn = document.getElementById('manualBumpBtn');

    let debounceTimer;

    // --- НАЧАЛО ИЗМЕНЕННОГО ФРАГМЕНТА ---

    // Единая функция для сохранения и перезапуска таймера
    const saveCooldownAndRestartAlarm = async () => {
        clearTimeout(debounceTimer); // Отменяем предыдущий отложенный запуск, если он был

        let value = parseInt(cooldownInput.value, 10);
        if (isNaN(value) || value < 5) { // Минимальное значение 5 минут
            value = 5;
            cooldownInput.value = 5; // Корректируем значение в поле ввода
        }

        await chrome.storage.local.set({ autoBumpCooldown: value });
        console.log(`[FunPay Boost] Интервал сохранен: ${value} мин.`);
        
        // Перезапускаем будильник, только если автоподнятие включено
        const data = await chrome.storage.local.get('autoBumpEnabled');
        if (data.autoBumpEnabled) {
            chrome.runtime.sendMessage({ action: 'startAutoBump', cooldown: value });
        }
        
        updateNextBumpTime(value);
    };

    // Обработчик поля интервала (применяется через 1 секунду после прекращения ввода)
    cooldownInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(saveCooldownAndRestartAlarm, 1000); // 1000ms = 1 секунда
    });

    // Дополнительный обработчик (применяется СРАЗУ, когда фокус уходит с поля)
    cooldownInput.addEventListener('change', () => {
        saveCooldownAndRestartAlarm(); // Вызываем сразу, без задержки
    });

    // --- КОНЕЦ ИЗМЕНЕННОГО ФРАГМЕНТА ---

    // Функция для обновления UI
    const updateUI = async () => {
        const data = await chrome.storage.local.get(['autoBumpEnabled', 'autoBumpCooldown']);
        toggle.checked = data.autoBumpEnabled || false;
        cooldownInput.value = data.autoBumpCooldown || 245;

        if (toggle.checked) {
            toggleLabel.textContent = "Автоподнятие включено";
            statusIndicator.classList.add('active');
            updateNextBumpTime(cooldownInput.value);
        } else {
            toggleLabel.textContent = "Автоподнятие выключено";
            statusIndicator.classList.remove('active');
            statusText.textContent = "Выключено";
        }
    };
    
    // Показываем время следующего поднятия
    const updateNextBumpTime = async (interval) => {
        try {
            const alarm = await chrome.alarms.get('funpayBoostAutoBump');
            if (alarm && toggle.checked) {
                const nextTime = new Date(alarm.scheduledTime).toLocaleTimeString();
                statusText.textContent = `Следующее поднятие в ${nextTime}`;
            } else if (toggle.checked) {
                 statusText.textContent = `Запланирует через ${interval} мин.`;
            } else {
                statusText.textContent = "Выключено";
            }
        } catch (e) {
            console.log("Не удалось получить будильник, возможно, он еще не создан.");
            statusText.textContent = "Ожидание...";
        }
    };

    // Обработчик переключателя
    toggle.addEventListener('change', async () => {
        await chrome.storage.local.set({ autoBumpEnabled: toggle.checked });
        if (toggle.checked) {
            chrome.runtime.sendMessage({ action: 'startAutoBump', cooldown: cooldownInput.value });
        } else {
            chrome.runtime.sendMessage({ action: 'stopAutoBump' });
        }
        updateUI();
    });

    // Обработчик кнопки принудительного поднятия
    manualBumpBtn.addEventListener('click', async () => {
        statusText.textContent = "Поднимаю лоты...";
        statusText.classList.add('loading');
        manualBumpBtn.disabled = true;

        const response = await chrome.runtime.sendMessage({ action: 'manualBump' });

        statusText.classList.remove('loading');
        manualBumpBtn.disabled = false;
        
        if (response.success) {
            statusText.textContent = response.message || "Готово!";
        } else {
            statusText.textContent = `Ошибка: ${response.error}`;
        }
        
        if(toggle.checked) {
            setTimeout(() => updateNextBumpTime(cooldownInput.value), 3000);
        }
    });

    // Инициализация UI при открытии
    updateUI();
});